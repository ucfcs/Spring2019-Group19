	#!/bin/bash
source devel/setup.bash
source /opt/ros/indigo/setup.bash
export ROS_PACKAGE_PATH=/path/to/workspace:$ROS_PACKAGE_PATH
roslaunch [packagename] [launchfile]
