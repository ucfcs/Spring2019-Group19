


getCameraID.js: Provides media device ID to be inputted in camera.js

Current IDs:

Camera 1: 0ae05783abe9a4c88167fb04bac674a1d5835932a406ab612f15cc3edb014ca5
Camera 2: 3f6521581004f984c7d69da2bbdcab817c7e637bdb02b5a54ddf80a7af4184c1

If camera needs to be changed, find new ID:

run video.html on browser
click inspect
look for videoinput id for new ID.
