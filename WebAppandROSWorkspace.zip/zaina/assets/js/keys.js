 B`NVVVBBBBBBBBBBBBBBBBBBFNGBBBBBBBBBBBBBBBBBBBBBBBBVfunction interactiveKeys() {

    this.keys = {
        KeyI: document.getElementsByClassName("up")[0],
        Comma: document.getElementsByClassName("down")[0],
        KeyJ: document.getElementsByClassName("left")[0],
        KeyL: document.getElementsByClassName("right")[0]
    }


    this.button = document.getElementById('toggle');
    this.startstopbutton = document.getElementById('startstop');


    this.mode = 'auto';

    this.toggleModes = () => {


        if ( this.mode == 'auto' ) {

            this.mode = 'manual';
        }

        else {

              text = 'Manual Mode Enabled';
              if (this.mode == 'manual') {
                alert("Please click stop");
              }
        }
        this.button.textContent = text;

    };


    this.handleKeys = ( e ) => {

        if ( this.mode == 'auto' ) return;

        let target = this.keys.up;

        switch (e.keyCode) {
            case 74:
                // Left Key Pressed
                target = this.keys.KeyJ;
                break;
                
            case 76:
                // Right Key Pressed
                target = this.keys.KeyL;
                break;
                
            case 73:
                // Up Key Pressed
                target = this.keys.KeyI;
                break;
                
            case 188:
                // Down Key Pressed
                target = keys.Comma;
                break;
	    case 75:
		target =this.keys.KeyK
		break;
        }

        if ( e.type == 'keydown' ) {
            target.classList.add("active");
        }

        else {
            target.classList.remove("active");
        }

    };

    this.listen = () => {

        window.addEventListener('keydown', this.handleKeys);
        window.addEventListener('keyup', this.handleKeys);
        this.button.addEventListener('click', this.toggleModes);
        this.startstopbutton.addEventListener('click', this.toggleStartStop);

    }

    this.listen();

}

function init() {

    const keys = interactiveKeys();

}

window.addEventListener("load", init);
