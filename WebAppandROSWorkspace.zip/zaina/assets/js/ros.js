var ros = new ROSLIB.Ros({
    url : 'ws://localhost:9090'
  });